var Configs = {
    API_ENDPOINT: "https://lunaai-apiapp.azurewebsites.net/api/",
    ISV_NAME: "Microsoft",
    AAD_APPID: "8c67d20f-b773-41fd-bd34-8d74292fc4d9",
    AAD_ENDPOINT: "https://lunaai-userapp.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#004578",
    ENABLE_V1: "true",
    ENABLE_V2: "true"
}
