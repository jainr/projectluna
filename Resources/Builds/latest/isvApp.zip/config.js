var Configs = {
    //API_ENDPOINT: "https://lunaaitest-apiapp.azurewebsites.net/api/",
    API_ENDPOINT: "https://localhost:44334/api",
    ISV_NAME: "Microsoft",
    AAD_APPID: "1158aaa3-b79f-42b4-8c07-10b7da5fb0fb",
    AAD_ENDPOINT: "http://localhost:4321",
    //AAD_ENDPOINT: "https://lunaaitest-isvapp.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#004578",
    ENABLE_V1: "true",
    ENABLE_V2: "true"
}
