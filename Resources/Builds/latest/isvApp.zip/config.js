var Configs = {
    API_ENDPOINT: "https://lunaailol-apiapp.azurewebsites.net/api/",
    ISV_NAME: "Microsoft",
    AAD_APPID: "ad47785e-4af7-4cca-bef2-3822deef258a",
    AAD_ENDPOINT: "https://lunaailol-isvapp.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#004578",
    ENABLE_V1: "true",
    ENABLE_V2: "true"
}
