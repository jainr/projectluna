var Configs = {
    API_ENDPOINT: "https://lunaailol-apiapp.azurewebsites.net/api/",
    ISV_NAME: "Microsoft",
    AAD_APPID: "24bf7494-cf6b-4675-bc2e-607f2c740897",
    AAD_ENDPOINT: "https://lunaailol-isvapp.azurewebsites.net",
    HEADER_BACKGROUND_COLOR: "#004578",
    ENABLE_V1: "true",
    ENABLE_V2: "true"
}
