from src.luna_publish.LunaPythonModel import LunaPythonModel
import numpy as np

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType

def init():
    global python_model
    python_model = LunaPythonModel()
    python_model.set_run_mode('azureml')
    python_model.load_context(None)

input_sample = np.array([[5.1,3.5,1.4,0.2]])
output_sample = np.array([1])

@input_schema('records', NumpyParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(userInput):
    result = python_model.predict(None, userInput)
    return result