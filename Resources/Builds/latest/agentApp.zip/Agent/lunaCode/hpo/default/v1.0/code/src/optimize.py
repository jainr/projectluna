from luna.lunaUtils import LunaUtils
import os
import pandas as pd
from datetime import datetime
from azureml.core import Run
from uuid import uuid4

utils = LunaUtils.Create()
args = utils.args
user_input = utils.user_input

input_folder_name = "inputs"
result_file_name = "result.csv"
output_folder_name = "outputs"

output = utils.DownloadOutputFilesFromPredecessorRun(input_folder_name)

lastResultFilePath = os.path.join(input_folder_name, result_file_name)

if output:
    for file in output:
        utils.logger.log_metric(str(uuid4()), file)

data = {'OperationId':[utils.args.operationId], 'Datetime':[str(datetime.now())]} 
if output and os.path.isfile(lastResultFilePath):
    df = pd.read_csv(lastResultFilePath, index_col=0)
    new_df = pd.DataFrame(data)
    df = df.append(new_df, ignore_index=True)
else:
    utils.logger.log_metric("output", "creating new")
    df = pd.DataFrame(data)
        
if not os.path.exists("output"):
    os.makedirs("output")

resultFilePath = os.path.join("output", "result.csv")

df.to_csv(resultFilePath)

utils.UploadOutputFiles("output")
