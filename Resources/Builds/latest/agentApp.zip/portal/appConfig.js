// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

/** @string Base API endpoint. */
var BASE_URL = 'https://lunaailol-agentapi.azurewebsites.net/api/management';
/** @string Header background color. (default color is: #3376CD) */
var HEADER_HEX_COLOR = "#3376CD";
/** @string Global site title. */
var SITE_TITLE = "TITLE OF OFFER/SERVICE";

/** AAD app configuration with options. */
var MSAL_CONFIG = {
  appId: '9348a48a-9f97-4e9e-bce2-40d239840733',
  /* 
    redirectUri: 'http://localhost:3000/', 
    redirectUri: 'https://luna-sa.azurewebsites.net/',
  */
  /** URL to redirect users after authorized. */
  redirectUri: 'https://luna-sa.azurewebsites.net/',
  scopes: [
    'user.read',
    'User.ReadBasic.All'
  ]
};