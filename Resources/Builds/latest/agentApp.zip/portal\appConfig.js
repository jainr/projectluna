var BASE_URL = "https://lunaaiagent1-api.azurewebsites.net/api/management";
var HEADER_HEX_COLOR = "#3376CD";
var SITE_TITLE = "Luna AI Agent";
var MSAL_CONFIG = {
  appId: "32194131-5cf5-4acd-b59c-d7671f882b70",
  redirectUri: "http://localhost:3000/",
  scopes: [
    "user.read",
    "User.ReadBasic.All"
  ]
};
