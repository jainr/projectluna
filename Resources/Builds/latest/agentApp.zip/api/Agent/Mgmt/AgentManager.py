class AgentManager(object):
    """description of class"""

    def __init__(self):
        return


